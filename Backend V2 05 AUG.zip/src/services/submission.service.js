const prisma =
  require("../config/prisma");

const storage =
  require("./storage.service");

const {
  notify,
} = require("./notification.service");

const MAX_TOTAL_FILES = 20;

function createServiceError(
  status,
  msg,
  data,
) {
  const error = new Error(msg);

  error.status = status;
  error.msg = msg;

  if (data !== undefined) {
    error.data = data;
  }

  return error;
}

async function getTaskForStudent({
  taskId,
  studentId,
}) {
  const task =
    await prisma.task.findUnique({
      where: {
        id: taskId,
      },

      include: {
        groups: {
          select: {
            groupId: true,
          },
        },
      },
    });

  if (!task) {
    throw createServiceError(
      404,
      "Task not found",
    );
  }

  const taskGroupIds =
    task.groups.map(
      (taskGroup) =>
        taskGroup.groupId,
    );

  if (!taskGroupIds.length) {
    throw createServiceError(
      403,
      "This task is not assigned to a group.",
    );
  }

  const membershipCount =
    await prisma.groupMembership.count({
      where: {
        studentId,

        groupId: {
          in: taskGroupIds,
        },
      },
    });

  if (membershipCount === 0) {
    throw createServiceError(
      403,
      "You are not assigned to this task",
    );
  }

  return task;
}

function getModificationState(
  task,
  now = new Date(),
) {
  const deadline =
    new Date(task.deadline);

  const afterDeadline =
    now > deadline;

  if (
    afterDeadline &&
    !task.allowLateSubmission
  ) {
    return {
      allowed: false,
      afterDeadline: true,

      message:
        "The deadline has passed and late submissions or modifications are not allowed for this task.",
    };
  }

  return {
    allowed: true,
    afterDeadline,

    message: afterDeadline
      ? "This homework was modified after the deadline."
      : null,
  };
}

async function mapSubmissionFile(
  file,
) {
  return {
    id: file.id,

    originalName:
      file.originalName,

    contentType:
      file.contentType,

    size: file.size,
    order: file.order,

    uploadedAfterDeadline:
      file.uploadedAfterDeadline,

    uploadedAt:
      file.uploadedAt,

    fileUrl:
      await storage.getSignedUrl(
        file.objectKey,
        15,
      ),
  };
}

async function mapSubmission(
  submission,
) {
  const files =
    await Promise.all(
      (submission.files || []).map(
        mapSubmissionFile,
      ),
    );

  let legacyFileUrl = null;

  if (submission.fileUrl) {
    legacyFileUrl =
      await storage.getSignedUrl(
        submission.fileUrl,
        15,
      );
  }

  let correctedFileUrl = null;

  if (
    submission.correctedFileUrl
  ) {
    correctedFileUrl =
      await storage.getSignedUrl(
        submission.correctedFileUrl,
        15,
      );
  }

  return {
    ...submission,

    fileUrl: legacyFileUrl,

    correctedFileUrl,

    files,

    fileCount: files.length,

    wasModifiedAfterDeadline:
      submission
        .lastModifiedAfterDeadline,

    canModify:
      submission.grade === null,
  };
}

async function findStudentSubmission({
  taskId,
  studentId,
}) {
  return prisma.submission.findUnique({
    where: {
      taskId_studentId: {
        taskId,
        studentId,
      },
    },

    include: {
      files: {
        orderBy: {
          order: "asc",
        },
      },

      task: {
        select: {
          id: true,
          title: true,
          deadline: true,
          allowLateSubmission: true,
          gradeOutOf: true,
        },
      },
    },
  });
}

/**
 * Creates a homework submission or adds
 * files to an existing ungraded submission.
 */
async function submitHomework({
  taskId,
  studentId,
  files,
}) {
  if (
    !Array.isArray(files) ||
    !files.length
  ) {
    throw createServiceError(
      400,
      "Select at least one homework file.",
    );
  }

  const task =
    await getTaskForStudent({
      taskId,
      studentId,
    });

  const modificationState =
    getModificationState(task);

  if (!modificationState.allowed) {
    throw createServiceError(
      400,
      modificationState.message,
    );
  }

  let submission =
    await findStudentSubmission({
      taskId,
      studentId,
    });

  if (
    submission &&
    submission.grade !== null
  ) {
    throw createServiceError(
      409,
      "This homework has already been graded and can no longer be modified.",
    );
  }

  const existingFileCount =
    submission?.files?.length || 0;

  if (
    existingFileCount +
      files.length >
    MAX_TOTAL_FILES
  ) {
    throw createServiceError(
      400,
      `A homework submission may contain a maximum of ${MAX_TOTAL_FILES} files.`,
      {
        existingFileCount,

        selectedFileCount:
          files.length,
      },
    );
  }

  const highestExistingOrder =
    (submission?.files || [])
      .reduce(
        (highest, file) =>
          Math.max(
            highest,
            Number(file.order || 0),
          ),
        -1,
      );

  const uploadedObjects = [];

  try {
    for (
      let index = 0;
      index < files.length;
      index += 1
    ) {
      const file = files[index];

      const objectKey =
        await storage.uploadBuffer(
          file.buffer,

          file.originalname ||
            `homework-${index + 1}`,

          file.mimetype ||
            "application/octet-stream",

          `homework-submissions/${taskId}/${studentId}`,
        );

      uploadedObjects.push({
        objectKey,

        originalName:
          file.originalname ||
          `homework-${index + 1}`,

        contentType:
          file.mimetype ||
          "application/octet-stream",

        size:
          Number.isFinite(
            Number(file.size),
          )
            ? Number(file.size)
            : file.buffer.length,

        order:
          highestExistingOrder +
          index +
          1,

        uploadedAfterDeadline:
          modificationState
            .afterDeadline,
      });
    }

    submission =
      await prisma.$transaction(
        async (tx) => {
          let currentSubmission =
            submission;

          if (!currentSubmission) {
            currentSubmission =
              await tx.submission.create({
                data: {
                  taskId,
                  studentId,

                  firstSubmittedAt:
                    new Date(),

                  submittedAt:
                    new Date(),

                  lastModifiedAt:
                    new Date(),

                  lastModifiedAfterDeadline:
                    modificationState
                      .afterDeadline,
                },
              });
          } else {
            currentSubmission =
              await tx.submission.update({
                where: {
                  id:
                    currentSubmission.id,
                },

                data: {
                  submittedAt:
                    new Date(),

                  lastModifiedAt:
                    new Date(),

                  lastModifiedAfterDeadline:
                    currentSubmission
                      .lastModifiedAfterDeadline ||
                    modificationState
                      .afterDeadline,
                },
              });
          }

          await Promise.all(
            uploadedObjects.map(
              (uploadedFile) =>
                tx.submissionFile.create({
                  data: {
                    submissionId:
                      currentSubmission.id,

                    objectKey:
                      uploadedFile.objectKey,

                    originalName:
                      uploadedFile.originalName,

                    contentType:
                      uploadedFile.contentType,

                    size:
                      uploadedFile.size,

                    order:
                      uploadedFile.order,

                    uploadedAfterDeadline:
                      uploadedFile
                        .uploadedAfterDeadline,

                    uploadedById:
                      studentId,
                  },
                }),
            ),
          );

          return tx.submission.findUnique({
            where: {
              id:
                currentSubmission.id,
            },

            include: {
              files: {
                orderBy: {
                  order: "asc",
                },
              },

              task: {
                select: {
                  id: true,
                  title: true,
                  deadline: true,
                  allowLateSubmission:
                    true,
                  gradeOutOf: true,
                },
              },
            },
          });
        },
      );
  } catch (error) {
    await Promise.allSettled(
      uploadedObjects.map(
        (uploadedFile) =>
          storage.deleteFile(
            uploadedFile.objectKey,
          ),
      ),
    );

    throw error;
  }

  return mapSubmission(submission);
}

/**
 * Returns the student's current submission
 * and signed file URLs.
 */
async function getMyHomeworkSubmission({
  taskId,
  studentId,
}) {
  await getTaskForStudent({
    taskId,
    studentId,
  });

  const submission =
    await findStudentSubmission({
      taskId,
      studentId,
    });

  if (!submission) {
    return null;
  }

  const modificationState =
    getModificationState(
      submission.task,
    );

  const mapped =
    await mapSubmission(submission);

  return {
    ...mapped,

    canModify:
      submission.grade === null &&
      modificationState.allowed,

    modificationBlockedReason:
      submission.grade !== null
        ? "This homework has already been graded."
        : modificationState.allowed
          ? null
          : modificationState.message,
  };
}

/**
 * Student removes one uploaded file.
 */
async function deleteHomeworkFile({
  submissionId,
  fileId,
  studentId,
}) {
  const submission =
    await prisma.submission.findFirst({
      where: {
        id: submissionId,
        studentId,
      },

      include: {
        files: {
          orderBy: {
            order: "asc",
          },
        },

        task: {
          select: {
            id: true,
            title: true,
            deadline: true,
            allowLateSubmission: true,
            gradeOutOf: true,
          },
        },
      },
    });

  if (!submission) {
    throw createServiceError(
      404,
      "Homework submission not found.",
    );
  }

  if (submission.grade !== null) {
    throw createServiceError(
      409,
      "This homework has already been graded and its files cannot be changed.",
    );
  }

  const modificationState =
    getModificationState(
      submission.task,
    );

  if (!modificationState.allowed) {
    throw createServiceError(
      400,
      modificationState.message,
    );
  }

  const file =
    submission.files.find(
      (item) =>
        item.id === fileId,
    );

  if (!file) {
    throw createServiceError(
      404,
      "Homework file not found.",
    );
  }

  await prisma.$transaction(
    async (tx) => {
      await tx.submissionFile.delete({
        where: {
          id: file.id,
        },
      });

      const remainingFiles =
        await tx.submissionFile.findMany({
          where: {
            submissionId:
              submission.id,
          },

          orderBy: {
            order: "asc",
          },
        });

      await Promise.all(
        remainingFiles.map(
          (
            remainingFile,
            index,
          ) =>
            tx.submissionFile.update({
              where: {
                id:
                  remainingFile.id,
              },

              data: {
                order: index,
              },
            }),
        ),
      );

      await tx.submission.update({
        where: {
          id:
            submission.id,
        },

        data: {
          submittedAt:
            new Date(),

          lastModifiedAt:
            new Date(),

          lastModifiedAfterDeadline:
            submission
              .lastModifiedAfterDeadline ||
            modificationState
              .afterDeadline,
        },
      });
    },
  );

  try {
    await storage.deleteFile(
      file.objectKey,
    );
  } catch (error) {
    console.error(
      "Failed to remove homework file from R2:",
      error.message,
    );
  }

  const updatedSubmission =
    await findStudentSubmission({
      taskId:
        submission.taskId,
      studentId,
    });

  return mapSubmission(
    updatedSubmission,
  );
}

/**
 * Direct grading — Teacher/Head, or an
 * eligible assistant.
 *
 * Multi-file corrected returns will be
 * implemented in the next step.
 */
async function gradeSubmission({
  submissionId,
  grade,
  comments,
  correctedFile,
  gradedBy,
}) {
  const submission =
    await prisma.submission.findUnique({
      where: {
        id: submissionId,
      },

      include: {
        task: {
          include: {
            groups: {
              select: {
                groupId: true,
              },
            },
          },
        },

        delegation: {
          select: {
            id: true,
            assistantId: true,
            completedAt: true,
          },
        },
      },
    });

  if (!submission) {
    throw createServiceError(
      404,
      "Submission not found",
    );
  }

  if (!gradedBy) {
    throw createServiceError(
      401,
      "Unauthorized",
    );
  }

  const isTeacher =
    gradedBy.role === "TEACHER";

  const isHeadAssistant =
    gradedBy.role === "ASSISTANT" &&
    gradedBy.isHeadAssistant === true;

  if (
    !isTeacher &&
    !isHeadAssistant
  ) {
    if (
      gradedBy.role !==
      "ASSISTANT"
    ) {
      throw createServiceError(
        403,
        "You are not allowed to grade this submission",
      );
    }

    const taskGroupIds =
      submission.task.groups.map(
        (taskGroup) =>
          taskGroup.groupId,
      );

    const assignmentCount =
      await prisma
        .assistantGroupAssignment
        .count({
          where: {
            assistantId:
              gradedBy.id,

            groupId: {
              in: taskGroupIds,
            },
          },
        });

    if (
      assignmentCount === 0
    ) {
      throw createServiceError(
        403,
        "You are not assigned to this submission's group",
      );
    }

    if (
      submission.delegation &&
      submission.delegation
        .assistantId !==
        gradedBy.id
    ) {
      throw createServiceError(
        403,
        "This submission was delegated to another assistant",
      );
    }
  }

  const numericGrade =
    Number(grade);

  const maximumGrade =
    Number(
      submission.task.gradeOutOf,
    );

  if (
    !Number.isFinite(
      numericGrade,
    )
  ) {
    throw createServiceError(
      400,
      "Grade must be a valid number",
    );
  }

  if (
    numericGrade < 0 ||
    numericGrade > maximumGrade
  ) {
    throw createServiceError(
      400,
      `Grade must be between 0 and ${maximumGrade}`,
    );
  }

  let correctedFileUrl =
    submission.correctedFileUrl;

  if (correctedFile) {
    correctedFileUrl =
      await storage.uploadBuffer(
        correctedFile.buffer,
        correctedFile.originalname,
        correctedFile.mimetype,
        "corrected",
      );
  }

  const graded =
    await prisma.$transaction(
      async (tx) => {
        const now = new Date();

        const updatedSubmission =
          await tx.submission.update({
            where: {
              id: submissionId,
            },

            data: {
              grade: numericGrade,

              comments:
                comments || null,

              correctedFileUrl,

              gradedAt: now,

              gradedById:
                gradedBy.id,
            },
          });

        if (
          submission.delegation &&
          submission.delegation
            .assistantId ===
            gradedBy.id &&
          !submission.delegation
            .completedAt
        ) {
          await tx.delegation.update({
            where: {
              id:
                submission
                  .delegation.id,
            },

            data: {
              completedAt: now,
            },
          });

          await tx
            .submissionDelegationHistory
            .create({
              data: {
                submissionId,

                delegationId:
                  submission
                    .delegation.id,

                action:
                  "COMPLETED",

                fromAssistantId:
                  gradedBy.id,

                toAssistantId:
                  gradedBy.id,

                changedById:
                  gradedBy.id,

                reason:
                  "Submission graded",
              },
            });
        }

        return updatedSubmission;
      },
    );

  notify({
    userId:
      submission.studentId,

    type: "GRADE_POSTED",

    title:
      "Your homework was graded",

    body:
      `You scored ${numericGrade}/${maximumGrade}`,

    link:
      `/my-tasks/${submission.taskId}`,
  }).catch((error) =>
    console.error(
      "notify() failed:",
      error.message,
    ),
  );

  return graded;
}

module.exports = {
  submitHomework,
  getMyHomeworkSubmission,
  deleteHomeworkFile,
  gradeSubmission,
};