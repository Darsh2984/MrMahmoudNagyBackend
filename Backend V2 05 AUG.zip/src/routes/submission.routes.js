const express =
  require("express");

const router =
  express.Router();

const submissionController =
  require("../controllers/submission.controller");

const {
  requireRole,
  requireAssistantPermission,
} = require("../middleware/rbac.middleware");

const {
  materialUpload,
} = require("../middleware/upload.middleware");

const {
  homeworkFilesUpload,
} = require("../middleware/homeworkUpload.middleware");

/**
 * Student uploads the first homework files
 * or adds files to an existing submission.
 *
 * Supports:
 * - files: multiple files
 * - file: legacy single file
 */
router.post(
  "/task/:taskId",
  requireRole("STUDENT"),
  homeworkFilesUpload,
  submissionController.submitHomework,
);

/**
 * Student retrieves their current submission,
 * signed R2 URLs and edit permissions.
 */
router.get(
  "/task/:taskId/mine",
  requireRole("STUDENT"),
  submissionController.getMyHomeworkSubmission,
);

/**
 * Student deletes one uploaded homework file.
 */
router.delete(
  "/:submissionId/files/:fileId",
  requireRole("STUDENT"),
  submissionController.deleteHomeworkFile,
);

/**
 * Existing direct grading endpoint.
 * Multi-file corrected returns will replace
 * this single correctedFile flow next.
 */
router.patch(
  "/:submissionId/grade",
  requireAssistantPermission(
    "canGradeHomework",
  ),
  materialUpload.single(
    "correctedFile",
  ),
  submissionController.gradeSubmission,
);

module.exports = router;