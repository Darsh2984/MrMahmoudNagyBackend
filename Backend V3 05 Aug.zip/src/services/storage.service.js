const crypto = require("crypto");
const path = require("path");

const {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
  GetObjectCommand,
} = require("@aws-sdk/client-s3");

const {
  getSignedUrl: createPresignedUrl,
} = require("@aws-sdk/s3-request-presigner");

function createStorageError(status, msg) {
  const error = new Error(msg);

  error.status = status;
  error.msg = msg;

  return error;
}

function getRequiredEnvironmentVariable(name) {
  const value = process.env[name];

  if (!value) {
    throw createStorageError(
      500,
      `${name} is not configured`,
    );
  }

  return value;
}

const accountId = getRequiredEnvironmentVariable(
  "R2_ACCOUNT_ID",
);

const accessKeyId = getRequiredEnvironmentVariable(
  "R2_ACCESS_KEY_ID",
);

const secretAccessKey =
  getRequiredEnvironmentVariable(
    "R2_SECRET_ACCESS_KEY",
  );

const bucketName = getRequiredEnvironmentVariable(
  "R2_BUCKET_NAME",
);

const r2 = new S3Client({
  region: "auto",

  endpoint:
    `https://${accountId}` +
    ".r2.cloudflarestorage.com",

  credentials: {
    accessKeyId,
    secretAccessKey,
  },
});

function normalizeFolder(folder) {
  if (
    typeof folder !== "string" ||
    !folder.trim()
  ) {
    return "misc";
  }

  return folder
    .trim()
    .replace(/^\/+|\/+$/g, "")
    .replace(/[^a-zA-Z0-9/_-]/g, "-");
}

function normalizeExtension(originalFilename) {
  return path
    .extname(originalFilename || "")
    .toLowerCase()
    .replace(/[^a-z0-9.]/g, "");
}

function getHttpStatusCode(error) {
  return error?.$metadata?.httpStatusCode;
}

function handleStoredFileError(error) {
  const statusCode = getHttpStatusCode(error);

  if (statusCode === 404) {
    throw createStorageError(
      404,
      "Stored file was not found",
    );
  }

  throw error;
}

async function streamToBuffer(body) {
  if (!body) {
    throw createStorageError(
      500,
      "The stored file returned no content",
    );
  }

  if (typeof body.transformToByteArray === "function") {
    const bytes = await body.transformToByteArray();

    return Buffer.from(bytes);
  }

  const chunks = [];

  for await (const chunk of body) {
    chunks.push(
      Buffer.isBuffer(chunk)
        ? chunk
        : Buffer.from(chunk),
    );
  }

  return Buffer.concat(chunks);
}

async function uploadBuffer(
  buffer,
  originalFilename,
  mimetype,
  folder = "misc",
) {
  if (
    !Buffer.isBuffer(buffer) ||
    buffer.length === 0
  ) {
    throw createStorageError(
      400,
      "The uploaded file is empty",
    );
  }

  const safeFolder = normalizeFolder(folder);

  const extension =
    normalizeExtension(originalFilename);

  const objectName =
    `${safeFolder}/${Date.now()}-` +
    `${crypto.randomBytes(8).toString("hex")}` +
    `${extension}`;

  await r2.send(
    new PutObjectCommand({
      Bucket: bucketName,
      Key: objectName,
      Body: buffer,

      ContentType:
        mimetype ||
        "application/octet-stream",

      CacheControl:
        "private, max-age=0, no-transform",

      Metadata: {
        originalname: encodeURIComponent(
          originalFilename ||
            "uploaded-file",
        ),
      },
    }),
  );

  return objectName;
}

async function downloadBuffer(objectName) {
  if (
    !objectName ||
    typeof objectName !== "string"
  ) {
    throw createStorageError(
      400,
      "A stored object key is required",
    );
  }

  let response;

  try {
    response = await r2.send(
      new GetObjectCommand({
        Bucket: bucketName,
        Key: objectName,
      }),
    );
  } catch (error) {
    handleStoredFileError(error);
  }

  const buffer = await streamToBuffer(
    response.Body,
  );

  if (!buffer.length) {
    throw createStorageError(
      500,
      "The stored file is empty",
    );
  }

  let originalName = null;

  if (response.Metadata?.originalname) {
    try {
      originalName = decodeURIComponent(
        response.Metadata.originalname,
      );
    } catch {
      originalName =
        response.Metadata.originalname;
    }
  }

  return {
    buffer,

    contentType:
      response.ContentType ||
      "application/octet-stream",

    size: buffer.length,

    originalName,
  };
}

async function deleteFile(objectName) {
  if (
    !objectName ||
    typeof objectName !== "string"
  ) {
    return;
  }

  try {
    await r2.send(
      new DeleteObjectCommand({
        Bucket: bucketName,
        Key: objectName,
      }),
    );
  } catch (error) {
    console.error(
      "R2 delete failed:",
      error.message,
    );
  }
}

async function getSignedUrl(
  objectName,
  expiresInMinutes = 5,
) {
  if (
    !objectName ||
    typeof objectName !== "string"
  ) {
    return null;
  }

  const expiresInSeconds =
    Math.max(
      1,
      Math.min(
        Number(expiresInMinutes) || 5,
        60,
      ),
    ) * 60;

  try {
    await r2.send(
      new HeadObjectCommand({
        Bucket: bucketName,
        Key: objectName,
      }),
    );
  } catch (error) {
    handleStoredFileError(error);
  }

  return createPresignedUrl(
    r2,
    new GetObjectCommand({
      Bucket: bucketName,
      Key: objectName,
    }),
    {
      expiresIn: expiresInSeconds,
    },
  );
}

async function getFileMetadata(objectName) {
  if (
    !objectName ||
    typeof objectName !== "string"
  ) {
    return null;
  }

  let response;

  try {
    response = await r2.send(
      new HeadObjectCommand({
        Bucket: bucketName,
        Key: objectName,
      }),
    );
  } catch (error) {
    handleStoredFileError(error);
  }

  let originalName = null;

  if (response.Metadata?.originalname) {
    try {
      originalName = decodeURIComponent(
        response.Metadata.originalname,
      );
    } catch {
      originalName =
        response.Metadata.originalname;
    }
  }

  return {
    contentType:
      response.ContentType ||
      "application/octet-stream",

    size:
      typeof response.ContentLength ===
      "number"
        ? response.ContentLength
        : null,

    originalName,
  };
}

module.exports = {
  uploadBuffer,
  downloadBuffer,
  deleteFile,
  getSignedUrl,
  getFileMetadata,
};