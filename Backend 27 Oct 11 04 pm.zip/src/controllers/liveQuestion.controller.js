const liveQuestionService = require("../services/liveQuestion.service");

async function createLiveQuestion(req, res) {
  try {
    const question = await liveQuestionService.createLiveQuestion({
      sessionId: req.body.sessionId,
      prompt: req.body.prompt,
      gradeOutOf: req.body.gradeOutOf,
      type: req.body.type,
      options: {
        A: req.body.optionA,
        B: req.body.optionB,
        C: req.body.optionC,
        D: req.body.optionD,
      },
      correctAnswer: req.body.correctAnswer,
      durationSeconds: req.body.durationSeconds,
      questionImage: req.file,
      createdBy: req.user,
    });

    res.json({ msg: "Live question created", question });
  } catch (err) {
    res
      .status(err.status || 500)
      .json({ msg: err.msg || "Error creating live question" });
  }
}
async function submitAnswer(req, res) {
  try {
    const answer = await liveQuestionService.submitAnswer({
      liveQuestionId: req.params.liveQuestionId,
      studentId: req.user.id,
      file: req.file,
      selectedOption: req.body.selectedOption,
      requestStartedAt: req.answerRequestStartedAt,
    });
    res.json({ msg: "Answer submitted", answer });
  } catch (err) {
    res.status(err.status || 500).json({ msg: err.msg || "Error submitting answer" });
  }
}

async function gradeAnswer(req, res) {
  try {
    const answer = await liveQuestionService.gradeAnswer({
      answerId: req.params.answerId,
      gradedBy: req.user,
      grade: req.body.grade,
    });

    res.json({ msg: "Answer graded", answer });
  } catch (err) {
    res
      .status(err.status || 500)
      .json({ msg: err.msg || "Error grading answer" });
  }
}

async function listAnswers(req, res) {
  try {
    const answers = await liveQuestionService.listAnswersForQuestion(
      req.params.liveQuestionId,
      req.user
    );

    res.json(answers);
  } catch (err) {
    res
      .status(err.status || 500)
      .json({ msg: err.msg || "Error listing answers" });
  }
}

module.exports = { createLiveQuestion, submitAnswer, gradeAnswer, listAnswers };
