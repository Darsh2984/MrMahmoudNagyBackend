const groupService = require("../services/group.service");

async function createGroup(req, res) {
  try {
    const group = await groupService.createGroup(req.body, req.user);
    res.json({ msg: "Group created", group });
  } catch (err) {
    res.status(err.status || 500).json({ msg: err.msg || "Error creating group" });
  }
}

async function listGroupsByYear(req, res) {
  try {
    const groups = await groupService.listGroupsByYear(
      req.params.yearId,
      req.user
    );

    res.json(groups);
  } catch (err) {
    res
      .status(err.status || 500)
      .json({
        msg: err.msg || "Error listing groups",
      });
  }
}

async function getGroup(req, res) {
  try {
    const group = await groupService.getGroupWithMembers(
      req.params.groupId,
      req.user
    );

    res.json(group);
  } catch (err) {
    res
      .status(err.status || 500)
      .json({
        msg: err.msg || "Error fetching group",
      });
  }
}


async function updateGroup(req, res) {
  try {
    const group = await groupService.updateGroup(req.params.groupId, req.body);
    res.json({ msg: "Group updated", group });
  } catch (err) {
    res.status(err.status || 500).json({ msg: err.msg || "Error updating group" });
  }
}

async function deleteGroup(req, res) {
  try {
    await groupService.deleteGroup(req.params.groupId);
    res.json({ msg: "Group deleted" });
  } catch (err) {
    res.status(err.status || 500).json({ msg: err.msg || "Error deleting group" });
  }
}


async function addStudent(req, res) {
  try {
    const studentIds = Array.isArray(
      req.body.studentIds
    )
      ? req.body.studentIds
      : null;

    if (studentIds) {
      const result =
        await groupService.addStudentsToGroup({
          groupId: req.params.groupId,
          studentIds,
          viewer: req.user,
        });

      return res.json({
        msg:
          result.added === 1
            ? "Student added to group"
            : "Students added to group",
        result,
      });
    }

    const membership =
      await groupService.addStudentToGroup({
        groupId: req.params.groupId,
        studentId: req.body.studentId,
        viewer: req.user,
      });

    return res.json({
      msg: "Student added to group",
      membership,
    });
  } catch (err) {
    return res
      .status(err.status || 500)
      .json({
        msg:
          err.msg ||
          "Error adding student to group",
      });
  }
}

async function removeStudent(req, res) {
  try {
    await groupService.removeStudentFromGroup({
      groupId: req.params.groupId,
      studentId: req.params.studentId,
      viewer: req.user,
    });
    res.json({ msg: "Student removed from group" });
  } catch (err) {
    res.status(err.status || 500).json({ msg: err.msg || "Error removing student from group" });
  }
}

async function updateSessionLink(req, res) {
  try {
    const group = await groupService.updateGroupSessionLink(
      req.params.groupId,
      req.body.sessionLink
    );

    res.json(group);
  } catch (error) {
    console.error(
      "updateSessionLink error:",
      error
    );

    res.status(error.status || 500).json({
      msg:
        error.msg ||
        error.message ||
        "Failed to update session link.",
    });
  }
}

async function updateSessionLinks(req, res) {
  try {
    const group = await groupService.updateGroupSessionLinks(
      req.params.groupId,
      req.body.sessionLinks,
    );

    return res.json({
      msg: "Session links updated.",
      group,
    });
  } catch (error) {
    console.error("updateSessionLinks error:", error);
    return res.status(error.status || 500).json({
      msg: error.msg || error.message || "Failed to update session links.",
    });
  }
}

module.exports = {
  createGroup,
  listGroupsByYear,
  getGroup,
  updateGroup,
  deleteGroup,
  addStudent,
  removeStudent,
  updateSessionLink,
  updateSessionLinks,
};
